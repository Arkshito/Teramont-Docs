export default [
  require('/home/container/node_modules/infima/dist/css/default/default.css'),
  require('/home/container/node_modules/@docusaurus/theme-classic/lib/prism-include-languages'),
  require('/home/container/node_modules/@docusaurus/theme-classic/lib/nprogress'),
  require('/home/container/src/css/custom.css'),
];
